/* 
 * File:   main.cpp
 * Author: Juwan Coanway
 * Created on January 11, 2018, 1:17 PM
 * Purpose: Validate the Truth Table
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int probNumber;
    
    //Process
    cout<<"Choose from the following menu"endl;
    cout<<"Problem 1 -> Author_Edition__Chapter_Problem"<<endl;
    cout<<"Problem 2 -> Author_Edition__Chapter_Problem"<<endl;
    cout<<"Problem 3 -> Author_Edition__Chapter_Problem"<<endl;
    cout<<"Problem 4 -> Author_Edition__Chapter_Problem"<<endl;
    cout<<"Problem 5 -> Author_Edition__Chapter_Problem"<<endl;
    cout<<"Problem 6 -> Author_Edition__Chapter_Problem"<<endl;
    cout<<"Problem 7 -> Author_Edition__Chapter_Problem"<<endl;
    cout<<"Problem 8 -> Author_Edition__Chapter_Problem"<<endl;
    cout<<"Problem 9 -> Author_Edition__Chapter_Problem"<<endl;
    cout<<"type 1 to 9 only"<<endl;
    cin<<probNumber;
    
    //output the 
    
    

    //Exit
    return 0;
}

